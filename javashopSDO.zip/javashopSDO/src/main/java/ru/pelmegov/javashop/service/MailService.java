package ru.pelmegov.javashop.service;

public interface MailService {

    public void sendEmail(final Object object);
}