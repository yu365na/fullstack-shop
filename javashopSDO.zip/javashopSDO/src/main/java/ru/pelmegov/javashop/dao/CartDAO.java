package ru.pelmegov.javashop.dao;

import ru.pelmegov.javashop.model.cart.Cart;

public interface CartDAO {

    public void updateCart(Cart cart);
}
