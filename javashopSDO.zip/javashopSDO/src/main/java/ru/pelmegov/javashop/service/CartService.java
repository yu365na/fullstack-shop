package ru.pelmegov.javashop.service;

import ru.pelmegov.javashop.model.cart.Cart;

public interface CartService {

    public void updateCart(Cart cart);
}
